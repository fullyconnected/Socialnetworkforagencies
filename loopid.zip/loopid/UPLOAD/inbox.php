<?
header("Location: mailbox.php?mailbox=inbox");
?>