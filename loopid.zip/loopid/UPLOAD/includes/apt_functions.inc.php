<?
require_once('bit_functions.inc.php');
require_once('user_functions.inc.php');
require_once('cross_use_functions.inc.php');

?>